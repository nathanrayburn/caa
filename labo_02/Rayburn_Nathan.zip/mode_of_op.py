from Crypto.Cipher import AES
from Crypto import Random
from Crypto.Util.strxor import strxor
from Crypto.Util.Padding import pad, unpad
from base64 import b64encode, b64decode
def encrypt(message, key):
    #pad the message
    message = pad(message, 16)
    
    cipher = AES.new(key, mode = AES.MODE_ECB)
    
    IV = Random.get_random_bytes(16)

    ciphertext= [IV]
    #First block
    m1 = message[:16]
    t = cipher.encrypt(m1)
    c1 = strxor(t, IV)
    ciphertext.append(c1)
    #Remaining blocks don't have an IV
    message_blocks = [message[16*(i+1):16*(i+2)] for i in range(len(message)//16-1)]
    for m in message_blocks:
        t = cipher.encrypt(t)
        c = strxor(t, m)
        ciphertext.append(c)

    return b"".join(ciphertext)




def test():
    key = Random.get_random_bytes(16)
    m1 = b"This is a long enough test message to check that everything is working fine and it does. This algorithm is super secure and we will try to sell it soon to the Swiss governement."
    c1 = encrypt(m1, key)
    print(b64encode(c1))


test()

